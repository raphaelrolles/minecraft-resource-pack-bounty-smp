BOUNTY SMP - RESOURCE PACK
============================================================

1) INSTALLATION SUR LE SERVEUR
   - Héberge ce .zip sur un lien de téléchargement DIRECT (ex: une 'Release' GitHub).
   - Dans server.properties :
       resource-pack=https://ton-lien-direct/BountySMP-ResourcePack.zip
       resource-pack-sha1=<le SHA-1 donné avec le pack>
       require-resource-pack=true
       resource-pack-prompt={"text":"Pack Bounty SMP"}
   - Redémarre le serveur. Chaque joueur reçoit le pack à la connexion.

2) ITEMS CUSTOM  (objet de base + CustomModelData)
   Le plugin donne l'objet de base avec ce CustomModelData, le pack remplace sa texture.
   Item                   Objet de base            CMD   
   Tracker de Prime       ECHO_SHARD               1001  
   Feu d'Artifice du Fugitif FIREWORK_ROCKET          1002  
   Fiole de Rage          GLASS_BOTTLE             1003  
   Grenade du Chaos       SNOWBALL                 1004  
   Élan du Chasseur       FEATHER                  1005  
   Bombe Puante           FERMENTED_SPIDER_EYE     1006  
   Bourse Chanceuse       SUSPICIOUS_STEW          1007  
   Œil de Judas           ENDER_EYE                1008  
   Bourse Trouée          STRING                   1009  
   Faux Lingot d'Or       GOLD_NUGGET              1010  
   Pierre de Rappel       AMETHYST_SHARD           1011  
   Bounty Coin (solde)    GOLD_INGOT               1012  

3) ICÔNES DE MENU  (objet de base PAPER)
   Icône invisible (case 'vide' cliquable)    PAPER  2000
   Bouton Boutique                            PAPER  2001
   Bouton Recherchés                          PAPER  2002
   Bouton Top Chasseurs                       PAPER  2003
   Bouton Quêtes                              PAPER  2004
   Retour au menu                             PAPER  2005
   Page précédente                            PAPER  2006
   Page suivante                              PAPER  2007
   Horloge (renouvellement)                   PAPER  2008
   Verrouillé / épuisé                        PAPER  2009
   Validé                                     PAPER  2010
   Vente de minerais                          PAPER  2011
   Offre du jour (%)                          PAPER  2012

4) FONDS DE MENUS  (police 'bountysmp:gui')
   Titre d'inventaire = texte BLANC, police bountysmp:gui, contenant \uF808 puis le glyphe.
   Menu         Glyphe   Cases    Hauteur  Titre dessiné
   menu_main    U+E000   27       168      BOUNTY SMP
   shop_kits    U+E001   36       186      BOUTIQUE - KITS
   shop_items   U+E002   36       186      BOUTIQUE - OBJETS
   shop_black   U+E003   36       186      MARCHE NOIR
   shop_deals   U+E004   36       186      OFFRES DU JOUR
   wanted       U+E005   27       168      WANTED
   top          U+E006   27       168      TOP CHASSEURS
   quests       U+E007   27       168      QUETES DU JOUR
   sell         U+E008   27       168      VENTE DE MINERAIS
   reel         U+E009   9        132      BOURSE CHANCEUSE

   Exemple (Java / Paper) :
       Component title = Component.text("\uF808\uE001")
               .font(Key.key("bountysmp", "gui")).color(NamedTextColor.WHITE);
       Inventory inv = Bukkit.createInventory(holder, 36, title);
       // et pour un item :  meta.setCustomModelData(1001);

5) COMPATIBILITÉ
   Le pack contient les deux systèmes : anciens 'overrides' (jusqu'à 1.21.3) et
   nouvelles définitions d'objets (1.21.4 et plus). Il est déclaré pour les formats 34+.
   Si le client affiche un avertissement 'pack fait pour une autre version', il se charge
   quand même : dis-moi la version exacte de ton serveur et j'ajuste pack.mcmeta.
